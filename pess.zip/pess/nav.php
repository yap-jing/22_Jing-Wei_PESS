<h1>Police Emergency Service System</h1>
<nav>
 <a href="logcall.php">Log Call</a>
 <a href="Update.php">Update</a>
 <a href="#">Report</a>
 <a href="#">History</a>
 </nav>